# JSON to XML Transformer Service

This FastAPI-based service:
1. Accepts JSON invoice data via HTTPS.
2. Injects it into a pre-defined XML template using Jinja2.
3. Posts the generated XML to a configurable remote HTTPS endpoint.

## Setup

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## Run Locally

```bash
export REMOTE_XML_POST_URL=https://example.com/receive-xml
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

## POST Example

```bash
curl -X POST http://localhost:8000/invoice \
     -H "Content-Type: application/json" \
     -d '{"number":"INV-001","client":"Acme","date":"2025-04-17","total":"1500"}'
```
