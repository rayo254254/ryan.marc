from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
from jinja2 import Environment, FileSystemLoader, select_autoescape
import httpx
import os

app = FastAPI()

env = Environment(
    loader=FileSystemLoader("app/templates"),
    autoescape=select_autoescape(["xml"])
)

REMOTE_XML_POST_URL = os.getenv("REMOTE_XML_POST_URL", "https://target-app.example.com/receive-xml")

@app.post("/invoice")
async def receive_invoice(request: Request):
    try:
        json_data = await request.json()
        template = env.get_template("invoice_template.xml")
        rendered_xml = template.render(invoice=json_data)

        async with httpx.AsyncClient() as client:
            response = await client.post(
                REMOTE_XML_POST_URL,
                content=rendered_xml,
                headers={"Content-Type": "application/xml"}
            )

        return JSONResponse({
            "status": "XML sent",
            "remote_status_code": response.status_code,
            "remote_response": response.text
        })

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
