from setuptools import setup, find_packages

setup(
    name="json-to-xml-service",
    version="0.1.0",
    packages=find_packages(include=["app", "app.*"]),
    install_requires=[
        "fastapi",
        "uvicorn",
        "httpx",
        "jinja2"
    ],
    entry_points={
        "console_scripts": [
            "start-service=app.main:app"
        ]
    },
)
